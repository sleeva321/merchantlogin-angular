package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.bean.Merchant;
import com.cg.dao.MerchantDao;

@Service
public class MerchantServiceImpl implements MerchantService{
	@Autowired
  MerchantDao dao;
	
	@Override
	public int loginByUsername(String uName, String pwd) {
		
		Merchant merchant=dao.getMerchantByUsername(uName);
	
		 if(merchant.getPwd().equals(pwd))
		 {
		        return merchant.getMerchant_id();}
		 
		return 0;

		
	}
	
	


}
